# FatecSRDSII202501
Repositório para arquivos das aulas de Desenvolvimento para Servidores II da Fatec de São Roque


//Notas do Aluno responsavel pela codificação do projeto ---------------------------------------------

Obviamente nao preciso disser que IA foi utilizada para auxiliar na codificação geral do projeto
porem, gostaria de deixar claro que ela so foi utilizada para praticamente copiar e colar partes do codigo e assim poupar tempo na codificação
cada pagina tem um numero razoavel de linhas e infelizmente estou com um tempo bem curto para o tanto de materia que estou me preocupado, entao essa foi uma solução
que acredito que muitos alem de mim utilizaram, porem quero deixar claro que o codigo foi totalmente feito em cima do material entregue alem de pequenas mudanças
proprias minhas em questão de organização e nome de variaveis
