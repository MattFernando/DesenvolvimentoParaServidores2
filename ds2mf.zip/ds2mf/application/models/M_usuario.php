<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_usuario extends CI_Model
{
    /*
    Validações de retorno (codigo de erro)
    0 - Erro de exceção
    1 - Operação realizada no banco de dados com sucesso
    4 - Usuario não validado no sistema
    5 - Usuario desativado no sistema
    6 - Usuario ão cadastrado no sistema
    8 - Houve algum problema com a ação (Inserir, atualizar, consultar ou excluir)
    98 - Método auxiliar de consulta que não trouxe dados
    */

    //Metodo Auxiliar para essa classe
    private function validaUsuario($usuario)
    {

        try {
            $retorno = $this->db->query("select * from tbl_usuario where usuario = '$usuario'");
            $linha = $retorno->row();

            if ($retorno->num_rows() == 0) {
                $dados = array('codigo' => 4,
                               'msg' => 'Usuário não existe na base de dados.');
            } else {
                if (trim($linha->estatus) == "D") {
                    $dados = array('codigo' => 5,
                                   'msg' => 'Usuário DESATIVADO NA BASE DE DADOS, não pode ser utilizado!');
                } else {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Usuário correto');
                }
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }

     private function validaIdUsuario($idUsuario){
        try {
            $retorno = $this->db->query("select * from tbl_usuario where id_usuario = $idUsuario");

            $linha = $retorno->row();

            if ($retorno->num_rows() == 0) {
                $dados = array('codigo' => 4,'msg' => 'Usuário não existe.');
            } else {
                if (trim($linha->estatus) == "D") {
                    $dados = array('codigo' => 5,
                                   'msg' => 'Usuário desativado, chame um adm');
                } else {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Usuário correto');
                }
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }

    public function inserir($nome, $email, $usuario, $senha){
        try{
            //verificar status antes de fazer insert
            $retornoUsuario = $this->validaUsuario($usuario);

            if($retornoUsuario['codigo'] == 4){
                $this->db->query("INSERT INTO tbl_usuario (nome,email,usuario,senha) VALUES('$nome','$email','$usuario',md5('$senha'))");

                //verificar se tudo deu certo
                if($this->db->affected_rows()>0){
                    $dados = array('codigo' => 1,
                    'msg' => 'Usuario cadastrado corretamente');
                }else{
                    $dados = array('codigo' => 8,
                    'msg' => 'Houve algum problema na inserção do usuario');
                }
            }else{
                    $dados = array('codigo' => $retornoUsuario['codigo'],
                    'msg' => $retornoUsuario['msg']);
                }
        }catch (Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',
                                       $e->getMessage());
        }
        //retornando os dados para o front
        return $dados;
    }

    public function consultar($nome, $email, $usuario)
    {
        try {
            //query para consulta
            $sql = "SELECT id_usuario, nome, usuario, email FROM tbl_usuario where estatus !='D'";

            if (trim($nome) != '') {
                $sql = $sql . " and nome like '%$nome%'";
            }
            if (trim($email) != '') {
                $sql = $sql . " and email = '$email'";
            }
            if (trim($usuario) != '') {
                $sql = $sql . " and usuario like '%$usuario%'";
            }

            $retorno = $this->db->query($sql);

            if ($retorno->num_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg' => 'Consulta realizada com sucesso',
                    'dados' => $retorno->result()
                );
            } else {
                $dados = array(
                    'codigo' => 98,
                    'msg' => 'Nenhum usuario encontrado com os filtros informados'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        //mandando os dados tratados para o controller
        return $dados;
    }

     public function alterar($idUsuario, $nome, $email, $senha){
        try {
            $retornoUsuario = $this->validaIdUsuario($idUsuario);

            if ($retornoUsuario['codigo'] == 1) {
                $query = "update tbl_usuario set ";

                if ($nome !== '') {
                    $query .= "nome = '$nome', ";
                }

                if ($email !== '') {
                    $query .= "email = '$email', ";
                }

                if ($senha !== '') {
                    $query .= "senha = md5('$senha'), ";
                }

                $queryFinal = rtrim($query, ", ") . " where id_usuario = $idUsuario";

                $this->db->query($queryFinal);

                if ($this->db->affected_rows() > 0) {
                    $dados = array('codigo' => 1,
                                   'msg' => 'Usuário atualizado corretamente.');
                } else {
                    $dados = array('codigo' => 8,
                                   'msg' => 'Houve algum problema na atualização na tabela de usuários.');
                }
            } else {
                $dados = array(
                    'codigo' => $retornoUsuario['codigo'],
                    'msg'    => $retornoUsuario['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array('codigo' => 00,
                           'msg' => 'ATENÇÃO: O seguinte erro aconteceu -> ',
                                       $e->getMessage());
        }

        return $dados;
    }

    public function desativar($idUsuario)
    {
        try {
            //verifica os estatus do usuario
            $retornaUsuario = $this->validaIdUsuario($idUsuario);
            if ($retornaUsuario['codigo'] == 1) {
                //query de desativação de usuario
                $this->db->query("update tbl_usuario set estatus = 'D' where id_usuario = $idUsuario");

                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Usuario desativado com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Houve um problema ao desativar o usuario'
                    );
                }
            }else{
                $dados = array(
                    'codigo' => $retornaUsuario['codigo'],
                    'msg' => $retornaUsuario['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        //retornando o array de dados tratado
        return $dados;
    }

    public function validaLogin($usuario, $senha)
    {   
        try{
                $retorno = $this->db->query("select * from tbl_usuario where usuario = '$usuario' and senha = md5('$senha') and estatus != 'D'");
                $linha = $retorno->row();
                if ($retorno->num_rows() == 0) {
                    $dados = array(
                        'codigo' => 4,
                        'msg' => 'Usuario ou senha inválidos'
                    );
                } else {
                    if(trim($linha->estatus) == 'D'){
                        $dados = array(
                            'codigo' => 5,
                            'msg' => 'Usuario desativado, caso precise, chame um administrador'
                        );
                    }else{
                        $dados = array(
                            'codigo' => 1,
                            'msg' => 'Login realizado com sucesso',
                        );
                    }
                }

        }catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }

}

