<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_professor extends CI_Model
{
    /*
Validações de retorno (codigo de erro)
0 - Erro de exceção
1 - Operação realizada no banco de dados com sucesso
8 - Houve algum problema com a ação (Inserir, atualizar, consultar ou excluir)
9 - Professor desativado no sistema
10- Professor já cadastrado
11- Professor não encontrado
98 - Método auxiliar de consulta que não trouxe dados
*/
    private function consultaProfessorCPF($cpf)
    {
        try {
            //Query para consultar se o codigo do professor já existe
            $sql = "select * from tbl_professor where cpf = '$cpf'";

            $retornoProfessor = $this->db->query($sql);

            //Verifica se a consulta funcionou
            if ($retornoProfessor->num_rows() > 0) {
                $linha = $retornoProfessor->row();
                if (trim($linha->estatus) == "D") {
                    $dados = array(
                        'codigo' => 9,
                        'msg' => 'Professor desativado, caso precise, chame um administrador'
                    );
                } else {
                    $dados = array(
                        'codigo' => 10,
                        'msg' => 'Professor já cadastrado'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Professor não encontrado'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }
    private function consultaProfessorCod($codigo)
    {
        try {
            //Query para consultar se o codigo do professor já existe
            $sql = "select * from tbl_professor where codigo = $codigo and estatus = ''";

            $retornoProfessor = $this->db->query($sql);

            //Verifica se a consulta funcionou
            if ($retornoProfessor->num_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg' => 'Professor encontrado',
                    'professor' => $retornoProfessor->row()
                );
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Professor não encontrado'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }

    public function inserir($nome, $cpf, $tipo)
    {
        try {
            //Verificar se o professor ja esta cadastrado
            $retornoConsulta = $this->consultaProfessorCPF($cpf);
            if ($retornoConsulta['codigo'] != 9 && $retornoConsulta['codigo'] != 10) {
                //Query para inserir o professor no banco de dados
                $this->db->query("insert into tbl_professor (nome, tipo, cpf) values ('$nome', '$tipo', '$cpf')");
                //verificando se tudo na inserção ocorreu bem
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Professor inserido com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Houve um problema ao inserir o professor'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => $retornoConsulta['codigo'],
                    'msg' => $retornoConsulta['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        //retornando o array de dados tratado
        return $dados;
    }

    public function consultar($codigo, $nome, $cpf, $tipo)
    {
        try {
            //Query para consultar os professores
            $sql = "select * from tbl_professor where estatus = '' ";
            if (trim($codigo) != '') {
                $sql = $sql . " and codigo = $codigo";
            }
            if (trim($nome) != '') {
                $sql = $sql . " and nome like '%$nome%'";
            }
            if (trim($cpf) != '') {
                $sql = $sql . " and cpf = $cpf";
            }
            if (trim($tipo) != '') {
                $sql = $sql . " and tipo = $tipo";
            }
            $sql = $sql . " order by nome";

            //mandando a query
            $retorno = $this->db->query($sql);
            //verificando se ocorreu tudo bem e se trouxe dados
            if ($retorno->num_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg' => 'Consulta realizada com sucesso',
                    'dados' => $retorno->result()
                );
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Nenhum professor encontrado'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        //retornando o array de dados tratado
        return $dados;
    }

    public function alterar($codigo, $nome, $cpf, $tipo)
    {
        try {
            //Verificar se o professor existe
            $consulta = $this->consultaProfessorCod($codigo);

            if ($consulta['codigo'] == 1) {
                //Query para atualização de dados
                $sql = "UPDATE tbl_professor SET ";
                //Verificar quais campos foram preenchidos para atualizar somente eles
                if ($nome !== '') {
                    $sql .= "nome = '$nome', ";
                }
                if ($cpf !== '') {
                    $sql .= "cpf = '$cpf', ";
                }
                if ($tipo !== '') {
                    $sql .= "tipo = '$tipo', ";
                }

                // Remover a última vírgula e espaço
                $sql = rtrim($sql, ', ') . " WHERE codigo = $codigo";
                //Executar a query
                $this->db->query($sql);
                //verificando se tudo deu certo com a atualização
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Professor atualizado com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Houve um problema ao atualizar o professor ou nenhum dado foi alterado'
                    );
                }
            }else {
                $dados = array(
                    'codigo' => $consulta['codigo'],
                    'msg' => $consulta['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        //retornando o array de dados tratado
        return $dados;
    }
    public function desativar($codigo)
    {
        try {
            //Verificar se o professor existe
            $consulta = $this->consultaProfessorCod($codigo);

            if ($consulta['codigo'] == 1) {
                //Query para desativar o professor
                $this->db->query("update tbl_professor set estatus = 'D' where codigo = $codigo");
                //verificando se tudo deu certo com a desativação
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Professor desativado com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Houve um problema ao desativar o professor'
                    );
                }
            }else{
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Professor não encontrado, nao pode excluir'
                );
            }
        }catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        //retornando o array de dados tratado
        return $dados;
    }
}
