<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_turma extends CI_Model
{
    /* 
Lista de validações de retornos (codigo de erro)
0 - Erro de exceção
1 - Operação realizada no banco de dados com sucesso
8 - Houve algum problema com a ação (Inserir, atualizar, consultar ou excluir)
9 - Turma desativada no sistema
10 - Turma já cadastrada
11 - Turma não encontrada pelo metodo publico
98 - Método auxiliar de consulta que não trouxe dados
*/

    //Metodo Auxiliar para essa classe

    private function ConsultaTurmaCod($codigo)
    {
        try {
            //Query para consultar se o codigo da turma já existe
            $sql = "select * from tbl_turma where codigo = $codigo ";

            $retornoTurma = $this->db->query($sql);

            //Verifica se a consulta funcionou
            if ($retornoTurma->num_rows() > 0) {
                $linha = $retornoTurma->row();
                if (trim($linha->estatus) == "D") {
                    $dados = array(
                        'codigo' => 9,
                        'msg' => 'Turma desativada, caso precise, chame um administrador'
                    );
                } else {
                    $dados = array(
                        'codigo' => 10,
                        'msg' => 'Turma já cadastrada'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => 98,
                    'msg' => 'turma não encontrada'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }
    public function consultarTurmaCodPublico($codigo){
        return $this->ConsultaTurmaCod($codigo);
    }


    public function inserir($descricao, $capacidade, $dataInicio)
    {
        try {
            //query para inserção de dados
            $this->db->query("insert into tbl_turma (descricao, capacidade, dataInicio) 
                                values('$descricao', $capacidade, '$dataInicio')");
            //Veridicando se a inserção foi realizada
            if ($this->db->affected_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg' => 'Turma inserida com sucesso'
                );
            } else {
                $dados = array(
                    'codigo' => 8,
                    'msg' => 'Houve um problema ao inserir a turma, tente novamente'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erro ocorreu: ' . $e->getMessage()
            );
        }
        //Retornando o array de dados tratado
        return $dados;
    }

    public function consultar($codigo, $descricao, $capacidade, $dataInicio)
    {
        try {
            $sql = "SELECT codigo, descricao, capacidade, dataInicio, date_format(dataInicio, '%d/%m/%Y') as dataInicioObra FROM tbl_turma WHERE estatus = '' ";

            if (trim($codigo) != '') {
                $sql .= " AND codigo = $codigo";
            }
            if (trim($descricao) != '') {
                $sql .= " AND descricao LIKE '%$descricao%'";
            }
            if (trim($capacidade) != '') {
                $sql .= " AND capacidade = $capacidade";
            }
            if (trim($dataInicio) != '') {
                $sql .= " AND dataInicio = '$dataInicio'";
            }

            $retorno = $this->db->query($sql);

            //Verifica se a consulta funcionou
            if ($retorno->num_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg' => 'Consulta realizada com sucesso',
                    'dados' => $retorno->result()
                );
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Nenhuma turma encontrada'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erro ocorreu: ' . $e->getMessage()
            );
        }
        //Enviando array de dados tratado
        return $dados;
    }

    public function alterar($codigo, $descricao, $capacidade, $dataInicio)
    {
        try {
            //Verificar se a turma existe
            $consulta = $this->ConsultaTurmaCod($codigo);

            if ($consulta['codigo'] == 10) {
                //Query para atualização de dados
                $sql = "UPDATE tbl_turma SET ";
                $updates = [];

                if ($descricao !== '') {
                    $updates[] = "descricao = '$descricao',";
                }
                if ($capacidade !== '') {
                    $updates[] = "capacidade = $capacidade,";
                }
                if ($dataInicio !== '') {
                    $updates[] = "dataInicio = '$dataInicio',";
                }

                // Remover a vírgula extra no final
                $sql .= rtrim(implode(' ', $updates), ',');

                // Adicionar a cláusula WHERE
                $sql .= " WHERE codigo = $codigo";

                // Executar a query
                $this->db->query($sql);

                //verificar se a atualização foi realizada
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Turma atualizada com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Houve um problema ao atualizar a turma, tente novamente'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Turma não encontrada'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erro ocorreu: ' . $e->getMessage()
            );
        }
        //Enviar array de dados tratado
        return $dados;
    }

    public function desativar($codigo)
    {
        try {
            //Verificar se a turma existe
            $consulta = $this->ConsultaTurmaCod($codigo);

            if ($consulta['codigo'] == 10) {
                //Executar a query
                $this->db->query("update tbl_turma set estatus = 'D' where codigo = $codigo");

                //verificar se a desativação foi realizada
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Turma desativada com sucesso'
                    );
                }else{
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Houve um problema ao desativar a turma, tente novamente'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Turma não encontrada'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erro ocorreu: ' . $e->getMessage()
            );
        }
        //enviar array de dados tratado
        return $dados;
    }
}
