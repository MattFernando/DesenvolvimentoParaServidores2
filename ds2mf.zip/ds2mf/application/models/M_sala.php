<?php
defined('BASEPATH') or exit('No direct script access allowed');

class M_sala extends CI_Model
{
    /* 
Lista de validações de retornos (codigo de erro)
0 - Erro de exceção
1 - Operação realizada no banco de dados com sucesso
8 - Houve algum problema com a ação (Inserir, atualizar, consultar ou excluir)
9 - Sala desativada no sistema
10 - Sala já cadastrada
98 - Método auxiliar de consulta que não trouxe dados
*/

    //Metodo Auxiliar para essa classe
    private function ConsultaSala($codigo)
    {
        try {
            //Query para consultar se o codigo da sala já existe
            $sql = "select * from tbl_sala where codigo = $codigo ";

            $retornoSala = $this->db->query($sql);

            //Verifica se a consulta funcionou
            if ($retornoSala->num_rows() > 0) {
                $linha = $retornoSala->row();
                if (trim($linha->estatus) == "D") {
                    $dados = array(
                        'codigo' => 9,
                        'msg' => 'Sala desativada, caso precise, chame um administrador'
                    );
                } else {
                    $dados = array(
                        'codigo' => 10,
                        'msg' => 'Sala já cadastrada'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => 98,
                    'msg' => 'sala não encontrada'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erros ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }
    public function inserir($codigo, $descricao, $andar, $capacidade)
    {
        try {
            //Verificar se a sala ja esta cadastrada
            $retornoConsulta = $this->ConsultaSala($codigo);
            if (
                $retornoConsulta['codigo'] != 9 &&
                $retornoConsulta['codigo'] != 10
            ) {
                //Query para inserir dados
                $this->db->query("insert into tbl_sala (codigo, descricao, andar, capacidade) values ($codigo, '$descricao', $andar, $capacidade)");
                //verificar se deu tudo certo
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Sala cadastrada com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Erro ao inserir na tabela SALAS'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => $retornoConsulta['codigo'],
                    'msg' => $retornoConsulta['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, o seguinte erro aconteceu: ' . $e->getMessage()

            );
        }
        return $dados;
    }

    public function Consultar($codigo, $descricao, $andar, $capacidade)
    {
        try {
            $sql = "select * from tbl_sala where estatus = '' ";

            if (trim($codigo) != '') {
                $sql = $sql . " and codigo = $codigo ";
            }
            if (trim($descricao) != '') {
                $sql = $sql . " and descricao like '%$descricao%' ";
            }
            if (trim($andar) != '') {
                $sql = $sql . " and andar = '$andar' ";
            }
            if (trim($capacidade) != '') {
                $sql = $sql . " and capacidade = '$capacidade' ";
            }
            $sql = $sql . " order by codigo";

            $retorno = $this->db->query($sql);

            if ($retorno->num_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg' => 'Consulta realizada com sucesso',
                    'dados' => $retorno->result()
                );
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'sala não encontrada'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção: O seguinte erro ocorreu: ' . $e->getMessage()
            );
        }
        return $dados;
    }

    public function Alterar($codigo, $descricao, $andar, $capacidade)
    {
        try {
            //Verifica se a sala existe
            $retornoConsulta = $this->ConsultaSala($codigo);
            if ($retornoConsulta['codigo'] == 10) {
                //Montar query para atualizar de acordo com o pedido
                $query = "update tbl_sala set ";
                //Comparação de itens para montar a query

                if ($descricao !== '') {
                    $query .= " descricao = '$descricao',  ";
                }
                if ($andar !== '') {
                    $query .= " andar = $andar,  ";
                }
                if ($capacidade !== '') {
                    $query .= " capacidade = $capacidade,  ";
                }

                //Remover a ultima virgula da query
                $queryfinal = rtrim($query, ",  ") . " where codigo = $codigo";

                //Executar a query
                $this->db->query($queryfinal);

                //Verificar se tudo ocorreu bem
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Sala atualizada com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Erro ao atualizar a sala'
                    );
                }
            }else{
                $dados = array(
                    'codigo' => $retornoConsulta['codigo'],
                    'msg' => $retornoConsulta['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, o seguinte erro ocorreu: ' . $e->getMessage()
            );
        }
        //Retornar os dados
        return $dados;
    }
    public function Desativar($codigo){
        try {
            //Verificar se a sala existe
            $retornoConsulta = $this->ConsultaSala($codigo);
            if ($retornoConsulta['codigo'] == 10) {
                //Query para desativar a sala
                $this->db->query("update tbl_sala set estatus = 'D' where codigo = $codigo");
                //Verificar se tudo ocorreu bem
                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Sala desativada com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 8,
                        'msg' => 'Erro ao desativar a sala'
                    );
                }
            }else{
                $dados = array(
                    'codigo' => $retornoConsulta['codigo'],
                    'msg' => $retornoConsulta['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, o seguinte erro ocorreu: ' . $e->getMessage()
            );
        }
        //Retornar os dados
        return $dados;
    }
}
