<?php
defined('BASEPATH') or exit('No direct script access allowed');

//Incluindo que precisaremos instanciar
include_once('M_sala.php');
include_once('M_professor.php');
include_once('M_turma.php');
include_once('M_horario.php');

class M_mapa extends CI_Model
{
    /* 
Lista de validações de retornos (codigo de erro)
0 - Erro de exceção
1 - Operação realizada no banco de dados com sucesso
7 - Reserva desativada no sistema
8 - A data esta ocupada para esta sala
9 - Houvre algum problema com a ação (Inserir, atualizar, consultar ou excluir)
10 - Reserva já cadastrada
11 - Reserva não encontrada pelo metodo publico
98 - Método auxiliar de consulta que não trouxe dados   
*/

    //metodo auxiliar para consulta de mapa
    private function consultaReservaTotal($dataReserva, $codSala, $codHorario)
    {
        try {
            //Query para consultar hora inicial e final
            $sql = "SELECT * FROM tbl_horario WHERE codigo = $codHorario";

            $retornoHorario = $this->db->query($sql);
            if ($retornoHorario->num_rows() > 0) {
                $linhaHorario = $retornoHorario->row();
                $horaInicio = $linhaHorario->hora_ini;
                $horaFim = $linhaHorario->hora_fim;

                //Query para consultar dados de acordo com parametros passados
                $sql = "SELECT * FROM tbl_mapa m, tbl_horario h WHERE m.datareserva = '" . $dataReserva . "' AND m.sala = $codSala 
            AND m.codigo_horario = $codHorario AND m.codigo_horario = h.codigo AND (h.hora_fim >= '" . $horaInicio . "' AND h.hora_ini <= '" . $horaFim . "')";
                $retornoMapa = $this->db->query($sql);

                //Verifica se a consulta funcionou
                if ($retornoMapa->num_rows() > 0) {
                    $linha = $retornoMapa->row();
                    if (trim($linha->estatus) == "D") {
                        $dados = array(
                            'codigo' => 7,
                            'msg' => 'Reserva desativada, caso precise, chame um administrador'
                        );
                    } else {
                        $dados = array(
                            'codigo' => 8,
                            'msg' => 'A data de ' . $dataReserva . ' esta ocupada para esta sala'
                        );
                    }
                } else {
                    $dados = array(
                        'codigo' => 11,
                        'msg' => 'Reserva não encontrada'
                    );
                }
            } else {
                $dados = array(
                    'codigo' => 11,
                    'msg' => 'Reserva não encontrada'
                );
            }
        } catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erro ocorreu: ' . $e->getMessage()
            );
        }
        //retornando o array de dados tratado
        return $dados;
    }

    public function inserir($dataReserva, $codSala, $codHorario, $codTurma, $codProfessor)
    {
        try {
            //Verificar se a reserva já esta cadastrada
            $retornoConsulta = $this->consultaReservaTotal($dataReserva, $codSala, $codHorario, $codTurma, $codProfessor);
            if ($retornoConsulta['codigo'] != 7 && $retornoConsulta['codigo'] != 8) {
                //Chamo o objeto para validação
                $salaOBJ = new M_sala();
                $retornoConsultaSala = $salaOBJ->Consultar($codSala, '', '', '');
                if ($retornoConsultaSala['codigo'] == 1) {
                    //Chamo o objeto para validação
                    $horarioOBJ = new M_horario();
                    $retornoConsultaHorario = $horarioOBJ->consultarHorarioPublico($codHorario, '', '');
                    if ($retornoConsultaHorario['codigo'] == 10) {
                        //Chamo o objeto para validação
                        $turmaOBJ = new M_turma();
                        $retornoConsultaTurma = $turmaOBJ->consultarTurmaCodPublico($codTurma);
                        if ($retornoConsultaTurma['codigo'] == 10) {
                            //Chamo o objeto para validação
                            $professorOBJ = new M_professor();
                            $retornoConsultaProfessor = $professorOBJ->consultar($codProfessor, '', '', '');
                            if ($retornoConsultaProfessor['codigo'] == 1) {
                                //query para inserção de dados
                                $this->db->query("insert into tbl_mapa (datareserva, sala, codigo_horario, codigo_turma, codigo_professor) values
                                ('" . $dataReserva . "', $codSala, $codHorario, $codTurma, $codProfessor)");

                                if ($this->db->affected_rows() > 0) {
                                    $dados = array(
                                        'codigo' => 1,
                                        'msg' => 'Reserva inserida com sucesso'
                                    );
                                } else {
                                    $dados = array(
                                        'codigo' => 9,
                                        'msg' => 'Houve um problema no agendamento'
                                    );
                                }
                            } else {
                                $dados = array(
                                    'codigo' => $retornoConsultaProfessor['codigo'],
                                    'msg' => $retornoConsultaProfessor['msg']
                                );
                            }
                        } else {
                            $dados = array(
                                'codigo' => $retornoConsultaTurma['codigo'],
                                'msg' => $retornoConsultaTurma['msg']
                            );
                        }
                    } else {
                        $dados = array(
                            'codigo' => $retornoConsultaHorario['codigo'],
                            'msg' => $retornoConsultaHorario['msg']
                        );
                    }
                } else {
                    $dados = array(
                        'codigo' => $retornoConsultaSala['codigo'],
                        'msg' => $retornoConsultaSala['msg']
                    );
                }
            } else {
                $dados = array(
                    'codigo' => $retornoConsulta['codigo'],
                    'msg' => $retornoConsulta['msg']
                );
            }
        } catch (Exception $e) {
            $dados = array("codigo" => 0, "msg" => "Atenção, um erro ocorreu: " . $e->getMessage());
        }
        //retornando o array de dados tratado
        return $dados;
    }

    public function consultar($codigo, $dataReserva, $codSala, $codHorario, $codTurma, $codProfessor){
        try{
            //query para consultar de acordo com os parametros passados
            $sql = "select m.codigo, date_format(m.datareserva, '%d-%m-%Y') as datareservabra, datareserva, m.sala, s.descricao as descsala, m.codigo_horario,
            h.descricao as deshorario, m.codigo_turma, t.descricao as descturma, m.codigo_professor, p.nome as nome_professor from tbl_mapa m, tbl_professor p,
            tbl_horario h, tbl_turma t, tbl_sala s
            where m.estatus = ''
            and m.codigo_professor = p.codigo
            and m.codigo_horario = h.codigo
            and m.codigo_turma   = t.codigo
            and m.sala           = s.codigo";
            if (trim($codigo) != '') {
                $sql = $sql . " and m.codigo = $codigo";
            }
            if (trim($dataReserva) != '') {
                $sql = $sql . " and m.datareserva = '$dataReserva'";
            }
            if (trim($codSala) != '') {
                $sql = $sql . " and m.sala = $codSala";
            }
            if (trim($codHorario) != '') {
                $sql = $sql . " and m.codigo_horario = $codHorario";
            }
            if (trim($codTurma) != '') {
                $sql = $sql . " and m.codigo_turma = $codTurma";
            }
            if (trim($codProfessor) != '') {
                $sql = $sql . " and m.codigo_professor = $codProfessor";
            }

            $sql = $sql . " order by m.datareserva, h.hora_ini, m.codigo_horario, m.sala";
            $retorno = $this->db->query($sql);
            //Verificar se a consulta ocorreu com sucesso
            if ($retorno->num_rows() > 0) {
                $dados = array(
                    'codigo' => 1,
                    'msg' => 'Consulta realizada com sucesso',
                    'dados' => $retorno->result()
                 );
             } else {
                 $dados = array(
                     'codigo' => 11,
                     'msg' => 'Reserva não encontrada'
                  );
              }
        }catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erro ocorreu: ' . $e->getMessage()
             );
         }
         //retornando o array de dados tratado
         return $dados;
    }

    public function alterar($codigo, $dataReserva, $codSala, $codHorario, $codTurma, $codProfessor){
    try {

        $retornoConsultaCodigo = $this->consultar($codigo, '', '', '', '', '');

        if($retornoConsultaCodigo['codigo'] != 1){
            return array(
                'codigo' => $retornoConsultaCodigo['codigo'],
                'msg' => $retornoConsultaCodigo['msg']
            );
        }

        $campos = array();

        if($dataReserva != ''){
            $campos[] = "datareserva = '$dataReserva'";
        }

        if($codSala != ''){
            $salaOBJ = new M_sala();
            $retornoConsultaSala = $salaOBJ->Consultar($codSala, '', '', '');

            if($retornoConsultaSala['codigo'] == 1){
                $campos[] = "sala = $codSala";
            } else {
                return array(
                    'codigo' => $retornoConsultaSala['codigo'],
                    'msg' => $retornoConsultaSala['msg']
                );
            }
        }

        if($codHorario != ''){
            $horarioOBJ = new M_horario();
            $retornoConsultaHorario = $horarioOBJ->consultarHorarioPublico($codHorario, '', '');

            if($retornoConsultaHorario['codigo'] == 1){
                $campos[] = "codigo_horario = $codHorario";
            } else {
                return array(
                    'codigo' => $retornoConsultaHorario['codigo'],
                    'msg' => $retornoConsultaHorario['msg']
                );
            }
        }

        if($codTurma != ''){
            $turmaOBJ = new M_turma();
            $retornoConsultaTurma = $turmaOBJ->consultarTurmaCodPublico($codTurma);

            if($retornoConsultaTurma['codigo'] == 1){
                $campos[] = "codigo_turma = $codTurma";
            } else {
                return array(
                    'codigo' => $retornoConsultaTurma['codigo'],
                    'msg' => $retornoConsultaTurma['msg']
                );
            }
        }

        if($codProfessor != ''){
            $professorOBJ = new M_professor();
            $retornoConsultaProfessor = $professorOBJ->consultar($codProfessor, '', '', '');

            if($retornoConsultaProfessor['codigo'] == 1){
                $campos[] = "codigo_professor = $codProfessor";
            } else {
                return array(
                    'codigo' => $retornoConsultaProfessor['codigo'],
                    'msg' => $retornoConsultaProfessor['msg']
                );
            }
        }

        // Verifica se existe algo para atualizar
        if(empty($campos)){
            return array(
                'codigo' => 9,
                'msg' => 'Nenhum dado informado para atualização'
            );
        }

        $sql = "UPDATE tbl_mapa SET " . implode(', ', $campos) . " WHERE codigo = $codigo";

        $this->db->query($sql);

        if($this->db->affected_rows() > 0){
            return array(
                'codigo' => 1,
                'msg' => 'Reserva atualizada com sucesso'
            );
        } else {
            return array(
                'codigo' => 9,
                'msg' => 'Nenhum dado foi alterado'
            );
        }

    } catch (Exception $e) {

        return array(
            'codigo' => 0,
            'msg' => 'Erro: ' . $e->getMessage()
        );
    }
         //retornando o array de dados tratado
         return $dados;
}
    public function desativar($codigo){
        try{
            //verificar se a reserva ja ta cadastrada
            $retornoConsultaCodigo = $this->consultar($codigo, '', '', '', '', '');

            if($retornoConsultaCodigo['codigo'] == 1){
                //query para desativação de dados
                $sql = "update tbl_mapa set estatus = 'D' where codigo = $codigo";
                $this->db->query($sql);

                if ($this->db->affected_rows() > 0) {
                    $dados = array(
                        'codigo' => 1,
                        'msg' => 'Reserva desativada com sucesso'
                    );
                } else {
                    $dados = array(
                        'codigo' => 9,
                        'msg' => 'Houve um problema na desativação'
                    );
                 }
            }else{
                $dados = array(
                    'codigo' => $retornoConsultaCodigo['codigo'],
                     'msg' => $retornoConsultaCodigo['msg']
                );  
            }
        }catch (Exception $e) {
            $dados = array(
                'codigo' => 0,
                'msg' => 'Atenção, um erro ocorreu: ' . $e->getMessage()
             );
         }
         //retornando o array de dados tratado
         return $dados;
    }
}