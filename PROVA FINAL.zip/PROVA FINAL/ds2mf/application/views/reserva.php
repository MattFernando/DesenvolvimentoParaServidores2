<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="../assets/css/reset.css">
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/styleCadastro.css">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.1/umd/popper.min.js" defer></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" defer></script>

    <title>Reserva</title>
    <link rel="icon" href="../../fatecsrdsii202502/assets/img/icone_fatecSR.ico" type="image/x-icon">
    <style>
        .navbar-nav {
            width: 100%;
            display: flex;
            justify-content: space-around;
        }

        .nav-item {
            flex-grow: 1;
            text-align: center;
        }

        .nav-link {
            display: block;
            color: #ffffff !important;
            font-weight: bold;
            padding: 0px;
        }

        .nav-link:hover {
            background-color: #44444e;
        }
        .main{
            margin-top: 150px;
        }
    </style>
</head>

<body>
    <header>
        <div id="headerMenu">
            <a href="../Funcoes/indexPagina">
                <h1 id="headerTitle">Mapeamento de Salas</h1>
            </a>

            <nav class="navbar navbar-expand-lg navbar-dark">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a class="nav-link" href="../Funcoes/abreSala">Sala de Aula</a></li>
                        <li class="nav-item"><a class="nav-link" href="../Funcoes/abreProfessor">Docente</a></li>
                        <li class="nav-item"><a class="nav-link" href="../Funcoes/abreTurma">Turma</a></li>
                        <li class="nav-item"><a class="nav-link" href="../Funcoes/abrePeriodo">Periodo</a></li>
                        <li class="nav-item"><a class="nav-link" href="../Funcoes/abreMapa">Reservas</a></li>
                        <li class="nav-item"><a class="nav-link" href="../Funcoes/abreRelatorio">Relatorio</a></li>
                    </ul>
                </div>
            </nav>
        </div>
    </header>

    <main>
        <section class="secao4" id="cadastroMapeamento">
            <div id="btnCadastroModal">
                <input type="text" id="inputMapeamento" class="form-control" placeholder="Pesquisar" onkeyup="filtrarTabela()">
                <button class="btn btn-outline-primary btnAcao modalBtn" id="botaoModal" type="button" data-toggle="modal" 
                data-target="#cadastroMapeamentoModal">
                    Cadastrar nova reserva</button>
            </div>
        </section>

    <div class="modal fade" id="cadastroMapeamentoModal" tabindex="-1" role="dialog" aria-labelledby="cadastroMapeamentoModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="cadastroMapeamentoModalLabel">Cadastrar Nova Reserva</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <form id="formCadastroMapeamento" method="post">
                    <div class="modal-body">
                        <div class="form-group row mb-2">
                            <div class="col-md-12">
                                <label for="selectSalas" class="col-form-label">Sala</label>
                                <select id="selectSalas" name="selectSalas" class="form-control" required>
                                    <option value="">Selecione uma sala</option>
                                </select>
                            </div>
                            <div class="col-md-12">
                                <label for="selectTurma" class="col-form-label">Turma</label>
                                <select id="selectTurma" name="selectTurma" class="form-control" required>
                                    <option value="">Selecione uma turma</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row mb-2">
                            <div class="col-md-12">
                                <label for="selectProfessor" class="col-form-label">Professor</label>
                                <select id="selectProfessor" name="selectProfessor" class="form-control" required>
                                    <option value="">Selecione um docente</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row mb-2">
                            <div class="col-md-6">
                                <label for="dataFim" class="col-form-label">Data Final</label>
                                <input type="date" id="dataFim" name="dataFim" class="form-control" required>
                            </div>
                            <div class="col-md-6">
                                <label for="selectHorario" class="col-form-label">Horário</label>
                                <select id="selectHorario" name="selectHorario" class="form-control" required>
                                    <option value="">Selecione um horário</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary">Cadastrar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
        <!-- Modal de Edição -->
    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="editModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editModalLabel">Editar Reserva</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <form id="formEditMapeamento" method="post">
                    <div class="modal-body">
                        <input type="hidden" id="editId" name="editId">
                        <div class="form-group mb-2">
                            <label for="editSelectSalas" class="col-form-label">Sala</label>
                            <select id="editSelectSalas" name="editSelectSalas" class="form-control" required>
                                <option value="">Selecione uma sala</option>
                            </select>
                        </div>
                        <div class="form-group mb-2">
                            <label for="editSelectTurma" class="col-form-label">Turma</label>
                            <select id="editSelectTurma" name="editSelectTurma" class="form-control" required>
                                <option value="">Selecione uma turma</option>
                            </select>
                        </div>
                        <div class="form-group mb-2">
                            <label for="editSelectProfessor" class="col-form-label">Professor</label>
                            <select id="editSelectProfessor" name="editSelectProfessor" class="form-control" required>
                                <option value="">Selecione um Professor</option>
                            </select>
                        </div>
                        <div class="form-group row mb-2">
                            <div class="col-md-5">
                                <label for="dataEditar" class="col-form-label">Data</label>
                                <input type="date" id="dataEditar" name="dataEditar" class="form-control" required>
                            </div>
                            <div class="col-md-7">
                                <label for="editSelectHorario" class="col-form-label">Horário</label>
                                <select id="editSelectHorario" name="editSelectHorario" class="form-control" required>
                                    <option value="">Selecione um Horário</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <section id="mostrarCadastro">
        <div class="table-responsive tabela-scroll">
            <div id="spinner" style="display: none; text-align: center; margin-top: 10px">
                <div class="spinner-border text-primary" role="status">
                    <span class="visually-hidden">Carregando...</span>
                </div>
            </div>
            <table class="table table-condensed table-hover">
                <thead>
                    <tr>
                        <th>Sala</th>
                        <th>Descrição da sala</th>
                        <th>Turma</th>
                        <th>Docente</th>
                        <th>Data</th>
                        <th>Horário</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody id="conteudo-Mapeamento"></tbody>
            </table>
        </div>
    </section>
</main>
<footer>
        <!-- Apenas para seguir o estilo css já definido para uma aparencia corrente-->
    </footer>
    <script src="../../ds2mf/assets/js/jquery-3.6.0.min.js"></script>
    <script src="../../ds2mf/assets/js/bootstrap.min.js"></script>
    <script src="../../ds2mf/assets/js/sweetalert2.all.min.js"></script>

<script>
    async function cadastro(event) {
    event.preventDefault();

    try {
        const sala = document.getElementById('selectSalas').value;
        const turma = document.getElementById('selectTurma').value;
        const professor = document.getElementById('selectProfessor').value;
        const horario = document.getElementById('selectHorario').value;
        const dataReserva = document.getElementById('dataFim').value;

        const response = await fetch('../Mapa/inserir', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                codSala: sala,
                codHorario: horario,
                codTurma: turma,
                codProfessor: professor,
                dataReserva: dataReserva
            })
        });
        const result = await response.json();
        console.log('Dados: ', result);

        if (result.sucesso) {
            $('#cadastroMapeamentoModal').modal('hide');
            Swal.fire('Sucesso!', result.msg, 'success');
            carregarDados();
        } else {
            const mensagemDeErro = result.erros.map(erro => {
                return `<p><strong>[${erro.campo ?? erro.codigo}]</strong> ${erro.msg}</p>`;
            }).join('');

            Swal.fire({
                title: 'Houve(ram) erro(s) de validação: ',
                html: mensagemDeErro,
                icon: 'error',
                confirmButtonText: 'Fechar'
            });
        }

    } catch (error) {
        console.error('Erro ao cadastrar Reserva: ', error);
        Swal.fire('Erro', 'Ocorreu um erro ao processar a requisição. ', 'error');
    }
}

const spinner = document.getElementById('spinner');

async function carregarDados() {
    try {
        const response = await fetch('../Mapa/consultar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                codigo: '',
                dataReserva: '',
                codSala: '',
                codHorario: '',
                codTurma: '',
                codProfessor: ''
            })
        });
                const result = await response.json();
                const conteudoAcesso = document.getElementById('conteudo-Mapeamento');

                conteudoAcesso.innerHTML = '';
                console.log(result);
                if (!result.sucesso || !result.dados || result.dados.length === 0) {
                    conteudoAcesso.innerHTML = '<tr><td colspan="4">Nenhum registro encontrado.</td></tr>';
                    return;
                }

                result.dados.forEach(item => {

                    conteudoAcesso.innerHTML += `
            <tr class="alert alert-warning">
            <td>${item.sala}</td>
                <td>${item.descsala}</td>
                <td>${item.descturma}</td>
                <td style="display:none">${item.codigo_turma}</td>
                <td>${item.nome_professor}</td>
                <td style="display:none">${item.codigo_professor}</td>
                <td>${item.datareservabra}</td>
                <td style="display:none">${item.datareserva}</td>
                <td>${item.deshorario}</td>
                <td style="display: none">${item.codigo_horario}</td>
                <td>
                    <div style="display: flex; gap: 10px; align-items: center;">
                        <button class="btn btn-warning btnAcao" onclick="openEditModal(this, ${item.codigo})">
                            <i class="fas fa-pencil"></i>
                        </button>
                        <button class="btn btn-danger btnAcao btnAcaoExcluir" onclick="deletarMapeamento(${item.codigo})">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>`;
                });


    } catch (error) {
        console.error('Erro ao carregar os dados: ', error);
    } finally {
        spinner.style.display = 'none';
    }
}

function debounce(func, delay) {
    let timer;
    return (...args) => {
        clearTimeout(timer);
        timer = setTimeout(() => func(...args), delay);
    };
}

const carregarDadosDebounced = debounce(carregarDados, 300);

function openEditModal(button, codigo) {
    const row = button.closest('tr');

    const sala = row.cells[1].innerText;
    const turma = row.cells[4].innerText;
    const professor = row.cells[6].innerText;
    const dataMapeamento = row.cells[8].innerText;
    const horario = row.cells[10].innerText;

    document.getElementById('editId').value = codigo;
    document.getElementById('editSelectSalas').value = sala;
    document.getElementById('editSelectTurma').value = turma;
    document.getElementById('editSelectProfessor').value = professor;
    document.getElementById('dataEditar').value = dataMapeamento;
    document.getElementById('editSelectHorario').value = horario;

    $('#editModal').modal('show');
}

// Salvar Edição
async function editarMapeamento(event) {
    event.preventDefault();

    try {
        const codigo = document.getElementById('editId').value;
        const sala = document.getElementById('editSelectSalas').value;
        const turma = document.getElementById('editSelectTurma').value;
        const professor = document.getElementById('editSelectProfessor').value;
        const dataMapeamento = document.getElementById('dataEditar').value;
        const horario = document.getElementById('editSelectHorario').value;

        const response = await fetch('../Mapa/alterar', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                codigo: codigo,
                codSala: sala,
                codHorario: horario,
                codTurma: turma,
                codProfessor: professor,
                dataReserva: dataMapeamento
            })
        });

        const result = await response.json();

        if (result.sucesso) {
            $('#editModal').modal('hide');
            Swal.fire('Sucesso!', result.msg, 'success');
            carregarDados();
        } else {
            const mensagemDeErro = result.erros.map(erro => {
                return `<p><strong>[${erro.campo ?? erro.codigo}]</strong> ${erro.msg}</p>`;
            }).join('');

            Swal.fire({
                title: 'Houve(ram) erros(s) de validação: ',
                html: mensagemDeErro,
                icon: 'error',
                confirmButtonText: 'Fechar'
            });
        }

    } catch (error) {
        console.error('Erro ao editar a reserva: ', error);
        Swal.fire('Erro', 'Ocorreu um erro ao processar a requisição.', 'error');
    }
}

// Deletar múltiplos
async function deletarMapeamentoMultiplos(codigo) {
    Swal.fire({
        title: 'Atenção!',
        text: 'Tem certeza que deseja remover essas reservas?',
        icon: 'question',
        showConfirmButton: true,
        showCancelButton: true,
        customClass: {
            confirmButton: 'btn btn-danger btnAcao',
            cancelButton: 'btn btn-secondary btnAcao'
        },
        buttonsStyling: false,
    }).then(async function (res) {
        if (res.isConfirmed) {
            const config = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ codigo: codigo })
            };
            const request = await fetch('../Mapa/desativarMultiplos', config);
            const response = await request.json();

            Swal.fire({
                title: 'Atenção!',
                text: response.msg,
                icon: response.sucesso ? 'success' : 'error',
                customClass: { confirmButton: 'btn btn-primary btnAcao' },
                buttonsStyling: false
            });
            carregarDados();
        }
    });
}

async function deletarMapeamento(codigo) {
    Swal.fire({
        title: 'Atenção!',
        text: 'Tem certeza que deseja remover essa reserva?',
        icon: 'question',
        showConfirmButton: true,
        showCancelButton: true,
        customClass: {
            confirmButton: 'btn btn-danger btnAcao',
            cancelButton: 'btn btn-secondary btnAcao'
        },
        buttonsStyling: false,
    }).then(async function (res) {
        if (res.isConfirmed) {
            const config = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ codigo: codigo })
            };
            const request = await fetch('../Mapa/desativar', config);
            const response = await request.json();

            Swal.fire({
                title: 'Atenção!',
                text: response.msg,
                icon: response.sucesso ? 'success' : 'error',
                customClass: { confirmButton: 'btn btn-primary btnAcao' },
                buttonsStyling: false
            });
            carregarDados();
        }
    });
}

function filtrarTabela() {
    const input = document.getElementById('inputPesquisa');
    const filter = input.value.toLowerCase();
    const tabela = document.getElementById('conteudo-Mapeamento');
    const linhas = tabela.getElementsByTagName('tr');

    for (let linha of linhas) {
        const celulas = linha.getElementsByTagName("td");

        if (celulas.length > 0) {
            const conteudoLinha = Array.from(celulas)
                .map(celula => celula.textContent.trim().toLowerCase()).join(" ");

            linha.style.display = conteudoLinha.includes(filter) ? "" : "none";
        }
    }
}

$(document).ready(function () {
    carregarDados();

    $('#cadastroMapeamentoModal').on('show.bs.modal', function () {
        $('#formCadastroMapeamento')[0].reset();
    });

    // Escuta do envio do formulário de cadastro
    $('#formCadastroMapeamento').on('submit', function (e) {
        cadastro(e);
    });

    // Escuta do envio do formulário de edição
    $('#formEditMapeamento').on('submit', function (e) {
        editarMapeamento(e);
    });

    // Requisições AJAX para lista
    // Salas
    $.ajax({
        url: '../Sala/consultar',
        method: "POST",
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({ codigo: '', descricao: '', andar: '', capacidade: '' }),
        success: function (retorno) {
            if (retorno.codigo == 1) {
                $.each(retorno.dados, function (index, item) {
                    const option = $('<option>', { value: item.codigo, text: item.codigo + " - " + item.descricao });
                    $('#selectSalas').append(option.clone());
                    $('#editSelectSalas').append(option);
                });
            }
        }
    });

    // Professores
    $.ajax({
        url: '../Professor/consultar',
        method: "POST",
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({ codigo: '', nome: '', cpf: '', tipo: '' }),
        success: function (retorno) {
            if (retorno.codigo == 1) {
                $.each(retorno.dados, function (index, item) {
                    const option = $('<option>', { value: item.codigo, text: item.nome });
                    $('#selectProfessor').append(option.clone());
                    $('#editSelectProfessor').append(option);
                });
            }
        }
    });

    // Turmas
    $.ajax({
        url: '../Turma/consultar',
        method: "POST",
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({ codigo: '', descricao: '', capacidade: '', dataInicio: '' }),
        success: function (retorno) {
            if (retorno.codigo == 1) {
                $.each(retorno.dados, function (index, item) {
                    const option = $('<option>', { value: item.codigo, text: item.descricao });
                    $('#selectTurma').append(option.clone());
                    $('#editSelectTurma').append(option);
                });
            }
        }
    });

    // Horários
    $.ajax({
        url: '../Horario/consultar',
        method: "POST",
        dataType: 'json',
        contentType: 'application/json',
        data: JSON.stringify({ codigo: '', descricao: '', horaInicial: '', horaFinal: '' }),
        success: function (retorno) {
            if (retorno.codigo == 1) {
                $.each(retorno.dados, function (index, item) {
                    const option = $('<option>', { value: item.codigo, text: item.descricao });
                    $('#selectHorario').append(option.clone());
                    $('#editSelectHorario').append(option);
                });
            }
        }
    });
});
</script>
</body>
</html>